$(document).ready(function(){
console.log($('body').outerHeight());
	$('.box').css('height',(0-135)+'px');
});