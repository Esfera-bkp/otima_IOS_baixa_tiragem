function enviaProposta(){
	
}