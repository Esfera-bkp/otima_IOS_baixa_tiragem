function carregaProdutos(){
	// <li>
 //           <a href="#"><img src="assets/img/agenda.png" /></a>
 //           <span class="line"></span>
 //           <a href="#">Agenda</a>
 //           </li>
}